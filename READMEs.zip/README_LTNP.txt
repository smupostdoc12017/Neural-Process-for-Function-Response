=============================
LT-NP runner — LTNP_Runner.py
=============================

Latent-tempered Neural Process with ACS-FW and BALD batch acquisition.

FILES NEEDED
------------

- LTNP_Runner.py
    Where it goes: the same folder as LTNP.py

- LTNP.py (the module)
    Where it goes: the folder you run the command from

- Scenario CSVs (scenario_XXX_<name>.csv)
    Where it goes: the scenario folder (see paths below)

The runner imports LTNP from the current working directory (line 18), so cd into the folder
that holds LTNP.py before running.

Python packages: numpy, pandas, scikit-learn, torch, matplotlib, openpyxl (Excel
summary).

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

- LTNP_Runner.py
    Line: 83
    What it is: save_dir – where results are written
    Current value: /users/your_username/Results/LTNP results

- LTNP.py
    Line: 2879
    What it is: RUNNER_SCENARIO_DIR – folder holding the scenario CSVs
    Current value: /users/your_username/paper scenarios

- LTNP.py
    Line: 76
    What it is: DATA_FILE – only used by the old standalone script, not by this runner
    Current value: C:\Users\your_username\...

The runner doesn't pass scenario_dir, so the CSV folder comes from LTNP.py line 2879. Instead of
editing the module, you can add scenario_dir="/your/path" to the call on lines 76–84.

HOW TO RUN
----------

    cd "/folder/containing/LTNP.py"
    python LTNP_Runner.py

The script has an if __name__ == "__main__": guard, so it is safe to run as a script (the workers
use spawn).

Choosing scenarios (lines 39–45)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Leave uncommented the scenarios you want to run (despite the comment on line 38, which says the
opposite). Matching is on the file name and ignores capitalisation. Currently only Gompertz runs.

Line 41 (#scenario_000_HGR.csv",) is missing its opening quote. If you uncomment it, write
"scenario_000_HGR.csv",, or Python raises a SyntaxError.

CPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------

- CPU only. The workers set CUDA_VISIBLE_DEVICES="", so GPUs are ignored even if present.
- Workers = min(n_cpu_workers, n_seeds, cores available to the job). Each worker is pinned to its
  own core (Linux) and limited to 1 thread.
- n_cpu_workers=8 (line 77): request at least 8 cores (e.g. #SBATCH --cpus-per-task=8). The
  runner prints Logical CPUs visible and CPU cores available at start-up, so you can check the
  allocation.
- Seeds are dealt round-robin to the workers: 16 seeds / 8 workers = 2 seeds each. Scenarios run one
  after another.
- To change the core count, change n_cpu_workers and request the same number of cores.

SEEDS
-----

- Seeds used: the first n_seeds entries of the fixed list in LTNP.py lines 106–111:
  1, 7, 11, 19, 23, 31, 37, 41, 55, 70, 99, 105, 121, 135, 160, 202, 82, 114, 303, 154.
  With n_seeds=16 (line 78) that is everything up to 202.
- Maximum is 20. A larger n_seeds raises ValueError.
- What a seed controls: which rows form the initial context (140), the pool (acq_rounds × batch
  = 150) and the validation set (everything else), plus NP initialisation and training randomness.
  ACS-FW and BALD share the same split within a seed.
- Influence: each seed is an independent replicate. Summaries average across seeds. More seeds
  give tighter estimates. Wall time ≈ ceil(n_seeds / workers) × time per seed, per scenario.
- n_plot_seeds=8 (line 79): how many of the seeds contribute to the averaged true-vs-predicted
  curves of the 9 fixed experiments. It must be between 1 and n_seeds.
- To use different seed values, edit the SEEDS list in LTNP.py lines 106–111.

OTHER SETTINGS (LINES 76–84)
----------------------------

- acq_rounds
    Value: 30
    Meaning: acquisition rounds; the pool is acq_rounds × 5

- initial_context_size
    Value: 140
    Meaning: initial labelled points

- lr
    Value: 1e-3
    Meaning: Adam learning rate

- (module default) epochs
    Value: 600
    Meaning: max NP epochs per fit (early stopping on validation)

Each scenario needs at least initial_context_size + acq_rounds×5 + 10 rows (300 with the current
settings).

Data layout: columns 0–6 are categorical inputs (one-hot encoded); column 7 is skipped; columns 8
onward are the response curve.

OUTPUTS (IN SAVE_DIR/<SCENARIO NAME>/)
--------------------------------------

all_seed_trajectories.csv, summary_trajectory.csv, initial_mape_round0.csv,
final_seed_summary.csv, selected_points.csv, config.csv,
final_validation_true_vs_predicted.csv, nine_validation_true_vs_pred_seed_averaged.csv,
mean_mape_trajectory.png, median_mape_trajectory.png, an .xlsx summary, and
<scenario>_nine_shared_experiment_ids.csv in save_dir.
