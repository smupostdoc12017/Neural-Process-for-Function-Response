==============================
IndGP runner — IndGP_Runner.py
==============================

Independent GP baseline: one scalar exact GP (GPyTorch, RBF-ARD kernel) per response-curve
coordinate, with no sharing across outputs. Acquisition strategies: ACS-FW and BALD.

FILES NEEDED
------------

- IndGP_Runner.py
    Where it goes: anywhere

- IndGP.py (the module)
    Where it goes: MODULE_DIR

- Scenario CSVs (scenario_XXX_<name>.csv)
    Where it goes: the same folder as IndGP.py (the runner sets BASE_DIR = MODULE_DIR,
      line 44)

Python packages: numpy, pandas, scikit-learn, torch, gpytorch.

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

These paths use the placeholder username (your_username) and should be adjusted for another machine.

- IndGP_Runner.py
    Line: 18
    What it is: MODULE_DIR – folder holding IndGP.py and the CSVs
    Current value: /users/your_username/paper scenarios

- IndGP_Runner.py
    Line: 82
    What it is: save_dir – where results are written
    Current value: /users/your_username/paper scenarios/IndGP results

- IndGP.py
    Line: 41
    What it is: SCENARIO_CSV_DIR – default only; the runner overrides it, so editing is
      optional
    Current value: /users/your_username/paper scenarios

On Windows use forward slashes, e.g. C:/Users/<you>/Desktop/scenarios.

HOW TO RUN
----------

    python IndGP_Runner.py

The script has an if __name__ == "__main__": guard, so it is safe to run as a plain script
(required, because the workers are started with spawn). On a SLURM cluster such as M3, wrap it in
a batch script that requests the cores described below.

Fix before running
~~~~~~~~~~~~~~~~~~

1. scenario_files is not an argument of IndGP.run_notebook_workflow. The call on lines
   60–83 passes scenario_files=[SCENARIO], which raises TypeError: unexpected keyword argument.
   The module selects scenarios with scenario_ids instead (the number in the file name), e.g.
   scenario_ids=[16] for scenario_016_damped.csv. With no scenario_ids, it runs every
   matching CSV in the folder.
2. Burnup and HGR share ID 0. scenario_ids=[0] runs both, and results are saved by numeric ID
   (scenario_000/), so the two would be written into the same folder. Run them from separate
   folders or separate save_dirs.
3. The runner's docstring says IndGP_Runner_Damped.py; the actual file name doesn't matter.

CPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------

- CPU only. No GPU is used.
- n_cpu_workers=8 (line 63) starts 8 worker processes, each restricted to 1 thread.
  Request at least 8 cores (e.g. #SBATCH --cpus-per-task=8). With fewer cores it still runs but the
  processes compete and it gets slower.
- Each job is one (scenario, seed) pair, so there are scenarios × 16 jobs shared among the workers.
- This is the most expensive per-fit model: each refit trains 144–145 separate GPs for
  train_epochs steps, and it refits after every acquisition round, for both strategies.
- To change the core count, change n_cpu_workers (line 63) and request the same number of cores.

SEEDS
-----

- Seeds used: 100, 101, …, 115 (16 seeds), hard-coded in IndGP.py line 498.
- n_seeds must be 16. Any other value raises ValueError (IndGP.py line 468).
- What a seed controls: the random 50/50 validation split, the initial context
  (min(64, len(train)//2) points), the remaining pool, and GP initialisation. BALD and ACS-FW
  share the same split within a seed.
- Influence: each seed is one independent replicate. Results are averaged across seeds, and the
  saved trajectory has 95% confidence intervals. More seeds give narrower intervals. Runtime grows
  roughly as ceil(scenarios × seeds / workers).
- To change the number of seeds: edit IndGP.py line 498 (seeds = list(range(100, 116))) and
  the check on lines 468–471, then pass the matching n_seeds.

OTHER SETTINGS (LINES 60–83)
----------------------------

- acq_rounds
    Value: 20
    Meaning: acquisition rounds

- batch
    Value: 5
    Meaning: points acquired per round

- val_frac
    Value: 0.5
    Meaning: fraction of rows held out as validation/test

- train_epochs
    Value: 300
    Meaning: Adam steps per GP fit

- lr
    Value: 0.03
    Meaning: learning rate

Data layout: columns 0–6 are categorical inputs (one-hot encoded); all columns from 7 onward
are treated as the response curve (column 7 is included).

OUTPUTS (IN SAVE_DIR/SCENARIO_XXX/)
-----------------------------------

- scenario_XXX_per_seed_mape.csv – context/pool/validation MAPE per seed, strategy and round
- scenario_XXX_trajectory.csv – mean, median and 95% CI of validation MAPE per round
