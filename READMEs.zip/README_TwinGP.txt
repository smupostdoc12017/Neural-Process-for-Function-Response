================================
TwinGP runner — GPTwin_Runner.py
================================

TwinGP-inspired global–local GP (Vakayil & Joseph): a global subset chosen by twinning plus local
nearest neighbours, with ACS-FW and BALD batch acquisition. Pure NumPy/SciPy; no PyTorch.

FILES NEEDED
------------

- GPTwin_Runner.py
    Where it goes: anywhere

- GPTwin.py (the module)
    Where it goes: MODULE_DIR

- Scenario CSVs
    Where it goes: BASE_DIR (currently the same folder as the module)

The runner imports a module named GPTwin, so the file must be called GPTwin.py. The
runner's docstring still mentions GP_TwinGP_parallel8.py; that is the same code under its old name.

Python packages: numpy, pandas, scipy, matplotlib.
Optional: twinning. If it is installed, the global subset is chosen by twinning; if not, a maximin
fallback is used. The start-up line Twinning pkg : says which. The two give different results,
so use the same choice on every computer you compare.

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

- GPTwin_Runner.py
    Line: 18
    What it is: MODULE_DIR – folder holding GPTwin.py
    Current value: /users/your_username/paper scenarios

- GPTwin_Runner.py
    Line: 19
    What it is: BASE_DIR – folder holding the CSVs (set equal to MODULE_DIR)
    Current value: MODULE_DIR

- GPTwin_Runner.py
    Line: 20
    What it is: SAVE_DIR – where results are written
    Current value: /users/your_username/Results/Twin GP results

- GPTwin.py
    Line: 28
    What it is: BASE_DIR – default only; the runner overrides it
    Current value: /users/your_username/paper scenarios

If the CSVs live somewhere else from the module, replace line 19 with that folder.

HOW TO RUN
----------

    python GPTwin_Runner.py

The script has an if __name__ == "__main__": guard, so it is safe to run as a script (the workers
use spawn).

To choose scenarios, edit scenario_files on line 34. Currently it runs only
scenario_000_burnup.csv. Example for several:
scenario_files=["scenario_000_HGR.csv", "scenario_016_damped.csv"].

CPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------

- CPU only. gpu_id is accepted but ignored.
- Workers = min(cpu_workers, number of seeds). cpu_workers=8 (line 36) with 8 seeds gives 8
  workers, one seed each, each limited to 1 numerical thread. Request at least 8 cores
  (e.g. #SBATCH --cpus-per-task=8).
- Scenarios run one after another; seeds within a scenario run in parallel.
- To change the core count, change cpu_workers and request the same number of cores. Wall time is
  about ceil(seeds / workers) seeds' worth per scenario.

SEEDS
-----

- Seeds used: seeds=tuple(range(100, 108)) (line 35), i.e. 100–107 (8 seeds).
- Seed 100 must be included. The 3×3 true-vs-predicted plots come from seed 100; without it the
  run stops with an error.
- What a seed controls: the 20% test split, the initial context (140), the pool, global-subset
  selection and ACS-FW sampling. BALD and ACS-FW share the same split within a seed.
- Influence: each seed is an independent replicate. The plot shows mean ± 1 SD across seeds, so
  more seeds give a more reliable average. Extra seeds cost nothing in wall time as long as there is a
  free worker for each.
- To change it: edit line 35, e.g. tuple(range(100, 116)) for 16 seeds (then use
  cpu_workers=16, or accept 2 seeds per worker with 8).

OTHER SETTINGS (LINES 31–43)
----------------------------

- initial_context_size
    Value: 140
    Meaning: initial labelled points

- acq_rounds
    Value: 20
    Meaning: acquisition rounds

- batch_size
    Value: 5
    Meaning: points per round

- acs_j
    Value: 50
    Meaning: samples for ACS-FW projections

- hyperopt_maxiter
    Value: 20
    Meaning: L-BFGS iterations for the global hyperparameters

- expected_num_outputs
    Value: None
    Meaning: the curve length is inferred from the file

Each scenario's training split (80% of rows) must hold at least
initial_context_size + acq_rounds × batch_size = 240 rows.

Data layout: columns 0–6 are categorical inputs (one-hot encoded); the response is the first
block of complete numeric columns after column 6 (it includes column 7 if that column is numeric).
Responses are standardised with the whole file's mean and SD; MAPE is computed on the original scale.

OUTPUTS (IN SAVE_DIR/<SCENARIO NAME>/)
--------------------------------------

metrics_trajectories.csv, test_mape_trajectories.png, ACS_FW_true_vs_predicted_9.png,
BALD_true_vs_predicted_9.png.
