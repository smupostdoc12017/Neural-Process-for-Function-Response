===============================
WPV-GP runner — WPVGP_Runner.py
===============================

Li & Tan-inspired separable shared-latent multi-output GP (GPyTorch LMC variational GP,
Matérn-3/2 ARD kernel on one-hot inputs). Three acquisition strategies: ACS-FW, BALD and
RWPV (a regression adaptation of Li & Tan's WPV criterion).

FILES NEEDED
------------

- WPVGP_Runner.py
    Where it goes: anywhere

- WPVGP.py (the module)
    Where it goes: MODULE_DIR

- Scenario CSVs
    Where it goes: base_dir

Python packages: numpy, pandas, scikit-learn, torch, gpytorch, matplotlib.

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

- WPVGP_Runner.py
    Line: 21
    What it is: MODULE_DIR – folder holding WPVGP.py
    Current value: /users/your_username/paper scenarios

- WPVGP_Runner.py
    Line: 46
    What it is: BASE_DIR – folder used for the file check
    Current value: /users/your_username/paper scenarios

- WPVGP_Runner.py
    Line: 78
    What it is: base_dir – folder the model actually reads the CSVs from
    Current value: /users/your_username/paper scenarios

- WPVGP_Runner.py
    Line: 88
    What it is: save_dir – where results are written
    Current value: /users/your_username/paper scenarios/WPVGP results

- WPVGP.py
    Line: 109
    What it is: DEFAULT_BASE_DIR – default only; the runner overrides it
    Current value: /users/your_username/paper scenarios

Lines 46 and 78 should point to the same folder.

HOW TO RUN
----------

    python WPVGP_Runner.py

Choosing scenarios
~~~~~~~~~~~~~~~~~~

There are two scenario lists:

- Lines 48–54: files checked before the run (each must have 144 response columns from column 8
  onward). They are all commented out now, so no check is done.
- Lines 79–85: files actually run. Currently only scenario_016_damped.csv.

Leave uncommented the scenarios you want, ideally in both lists.

The burnup entry is spelled Scenario_000_burnupp.csv (capital S, double p). Linux file names are
case-sensitive, so it will fail unless that is the real file name. The other files use
scenario_000_burnup.csv.

CPU / GPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------------

- Single process, no parallel workers. Seeds, strategies and scenarios run one after another.
- gpu_id=0 (line 97): uses GPU 0 if CUDA is available, otherwise the CPU. If a GPU is visible,
  gpu_id must be smaller than the number of GPUs, or it raises ValueError.
- On CPU, PyTorch uses its default multithreading (no thread limit is set), so a few cores help, but
  extra cores won't parallelise across seeds. One GPU (or a modest core count such as 4–8) is enough.
- To use a different GPU, change gpu_id.

SEEDS
-----

- Number: num_seeds=16 (line 99). The module default is 20.
- Seed values: replicate r (0 to 15) uses split seed split_seed + r and training seed
  train_seed + r. With split_seed=1 (line 95) and train_seed=220 (line 96), that is split seeds
  1–16 and training seeds 220–235.
- What a seed controls: the 20% test set, the initial context (140), the pool, inducing-point
  choice and training randomness. All three strategies share the same split and the same initial
  fitted model within a replicate.
- Influence: each seed is an independent replicate. The plot shows mean ± 1 SD across seeds.
  Runtime is linear in num_seeds because nothing runs in parallel.
- To change it: edit num_seeds, split_seed or train_seed on lines 95–99.

OTHER SETTINGS (LINES 77–100)
-----------------------------

- acq_rounds
    Value: 20
    Meaning: acquisition rounds

- batch_size
    Value: 5
    Meaning: points per round

- num_latents
    Value: 1
    Meaning: latent GPs (1 = rank-one shared structure)

- num_inducing
    Value: 30
    Meaning: inducing points per latent

- train_epochs
    Value: 300
    Meaning: max Adam steps per fit (early stopping on the ELBO)

- lr
    Value: 0.03
    Meaning: learning rate

- acs_j
    Value: 50
    Meaning: samples for ACS-FW projections

- initial_context_size
    Value: 140
    Meaning: initial labelled points

- expected_num_outputs
    Value: 144
    Meaning: required response columns from column 8 onward

Each scenario needs enough rows for a 20% test set, 140 context points and at least
acq_rounds × batch_size = 100 pool points.

OUTPUTS (IN SAVE_DIR/<SCENARIO NAME>/)
--------------------------------------

metrics_all_strategies.csv, mape_trajectories_all_strategies.png, and
true_vs_predicted_ACS_FW.png, true_vs_predicted_BALD.png and true_vs_predicted_RWPV.png (first
replicate, final model). Existing copies of these files are overwritten.
