==================================
R1-MTGP runner — R1-MTGP_Runner.py
==================================

Rank-one exact multitask GP (GPyTorch, RBF-ARD input kernel, rank-one task covariance across curve
positions) with ACS-FW and BALD batch acquisition.

READ FIRST: THE UPLOADED MODULE IS THE WRONG MODEL
--------------------------------------------------

The file uploaded as R1-MTGP.py is the TwinGP code. Apart from its 7-line header it is
identical to GPTwin.py. With that file, the runner stops at once (assert
base.EXPECTED_NUM_OUTPUTS == 144 fails, because TwinGP sets it to None). If the assert were
removed, it would run TwinGP, silently ignore n_gpus, n_seeds, epochs and lr, and save TwinGP
results under an R1-MTGP folder.

Use the real R1-MTGP module instead: the parallel GP_base.py from Oct 21, 2026, renamed
R1_MTGP.py (underscore, not hyphen; Python can't import a name containing -).
The rest of this README describes that module.

FILES NEEDED
------------

- R1-MTGP_Runner.py
    Where it goes: anywhere

- R1_MTGP.py (the R1-MTGP module)
    Where it goes: MODULE_DIR

- Scenario CSVs
    Where it goes: BASE_DIR

Python packages: numpy, pandas, torch, gpytorch, matplotlib.

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

These are Windows paths using a placeholder user account.

- R1-MTGP_Runner.py
    Line: 8
    What it is: MODULE_DIR – folder holding R1_MTGP.py
    Current value: C:/Users/your_username/Desktop/Scenarios to Run

- R1-MTGP_Runner.py
    Line: 32
    What it is: BASE_DIR – folder holding the scenario CSVs
    Current value: C:/Users/your_username/Desktop/Scenarios to Run

- R1-MTGP_Runner.py
    Line: 76
    What it is: save_dir – where results are written
    Current value: C:/Users/your_username/Desktop/base results 16

HOW TO RUN
----------

Run it in Jupyter (or an IPython console), not as python R1-MTGP_Runner.py.

- Line 59 (%matplotlib inline) is a notebook command and is a SyntaxError in a plain script.
- The script has no if __name__ == "__main__": guard. Parallel workers re-import the main file
  when it is a script, which re-launches the whole run. In a notebook this doesn't happen.

To run it as a script instead, delete line 59 and put everything below the imports inside
def main(): with an if __name__ == "__main__": main() guard.

The runner first checks that every CSV in SCENARIO_FILES (lines 33–39) exists and has 144
response columns from column 8 onward (column 7 is skipped). It stops with an error otherwise.
Comment out scenarios you don't want to run in both places they are used (the list on lines
33–39 feeds the call on line 66).

CPU / GPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------------

- n_gpus=8 (line 67) sets 8 parallel workers.
  - With GPUs visible: one worker per GPU, up to 8.
  - With no GPU: 8 CPU worker processes, each limited to 1 thread. Request at least 8 cores.
- The runner prints GPUs visible: at start-up, so you can confirm which mode you are in.
- Do not pass gpu_id. It forces a single sequential worker.
- Unknown arguments raise TypeError (num_latents, num_inducing, split_seed and train_seed
  are not accepted).
- To change the parallelism, change n_gpus and request the matching GPUs or cores.
- Finished (scenario, seed) jobs are saved in save_dir/_partial/. Rerunning with the same
  settings resumes; rerunning with different settings raises an error (use a new save_dir, or
  pass resume=False to overwrite).

SEEDS
-----

- Seeds used: 100, 101, …, 100 + n_seeds − 1. With n_seeds=16 (line 68): 100–115.
- Distribution: seeds are shared among the workers. 16 seeds / 8 workers = 2 seeds per worker,
  so wall time is about 2 seeds' worth.
- What a seed controls: the train/test split, the initial context (64 points), model
  initialisation and ACS-FW sampling. Each job is reseeded internally, so the result doesn't depend on
  which worker runs it.
- Influence: each seed is an independent replicate. Results are averaged across seeds, so more
  seeds give tighter estimates. Wall time grows with ceil(n_seeds / workers).
- To change it: set n_seeds on line 68.

OTHER SETTINGS (LINES 64–77)
----------------------------

- acq_rounds
    Value: 20
    Meaning: acquisition rounds

- batch_size
    Value: 5
    Meaning: points acquired per round

- epochs
    Value: 300
    Meaning: Adam steps per fit (train_epochs is accepted as an alias)

- lr
    Value: 0.03
    Meaning: learning rate

- acs_j
    Value: 50
    Meaning: posterior samples for ACS-FW projections

- initial_context_size
    Value: 64
    Meaning: initial labelled points

- expected_num_outputs
    Value: 144
    Meaning: required response-curve length

Input encoding: the 7 categorical levels are used as numbers and z-scored. They are not one-hot
encoded, unlike the other models.

OUTPUTS (IN SAVE_DIR/<SCENARIO NAME>/)
--------------------------------------

per_seed_metrics.csv, selected_points.csv, per_seed_diversity.csv, per_seed_runtime.csv,
aggregate_metrics.csv, aggregate_diversity.csv, final_summary.csv, data_layout.csv,
pred_vs_true_samples.csv, MAPE/MSE trajectory plots, and in save_dir/:
all_scenarios_final_summary.csv and run_config.csv.
