================================
FedMGP runner — FedMGP_Runner.py
================================

Federated multi-output GP (Chung & Al Kontar 2024, Technometrics) with shared latent GPs, used
as the surrogate in a BALD / ACS-FW active-learning loop. Each response-curve coordinate is
one FedMGP "unit".

FILES NEEDED
------------

- FedMGP_Runner.py
    Where it goes: anywhere

- FedMGP.py (the module)
    Where it goes: MODULE_DIR

- Scenario CSVs
    Where it goes: base_dir

Python packages: numpy, pandas, scikit-learn, torch, matplotlib.

PATHS YOU MUST CHANGE ON ANOTHER COMPUTER
-----------------------------------------

- FedMGP_Runner.py
    Line: 21
    What it is: MODULE_DIR – folder holding FedMGP.py
    Current value: /users/your_username/paper scenarios

- FedMGP_Runner.py
    Line: 46
    What it is: BASE_DIR – folder used for the file check
    Current value: /users/your_username/paper scenarios

- FedMGP_Runner.py
    Line: 77
    What it is: base_dir – folder the model actually reads the CSVs from
    Current value: /users/your_username/paper scenarios

- FedMGP_Runner.py
    Line: 88
    What it is: save_dir – where results are written
    Current value: /users/your_username/paper scenarios/synthetic

- FedMGP.py
    Line: 133, 1053
    What it is: default folders only; the runner overrides them
    Current value: /users/your_username/paper scenarios

Lines 46 and 77 should point to the same folder.

HOW TO RUN
----------

    python FedMGP_Runner.py

Choosing scenarios
~~~~~~~~~~~~~~~~~~

There are two scenario lists:

- Lines 47–54: files checked before the run (each must have 145 response columns from column 7
  onward). They are all commented out now, so no check is done.
- Lines 78–85: files actually run. Currently damped, Gompertz and sigmoid.

Leave uncommented the scenarios you want, ideally in both lists.

Two traps in these lists:

1. Missing comma. Line 79 ("Scenario_000_burnupp.csv") has no trailing comma. If you uncomment
   it together with the next line, Python silently joins the two names into one file name that
   doesn't exist. Add the comma.
2. Spelling. The burnup name is Scenario_000_burnupp.csv (capital S, double p). Linux is
   case-sensitive, so use the real file name (scenario_000_burnup.csv in the other runners).

Each run deletes the existing save_dir/<scenario name>/ folder before writing. Change
save_dir if you want to keep earlier results.

CPU / GPU REQUIREMENTS AND HOW TO TWEAK THEM
--------------------------------------------

- Single process, no parallel workers. Seeds, strategies and scenarios run one after another.
- gpu_id=0 (line 94): uses GPU 0 if CUDA is available, otherwise the CPU. If a GPU is visible,
  gpu_id must be smaller than the number of GPUs.
- The model runs in float64, and the federated training step is batched over all 145 units, so a
  GPU helps a lot. On CPU, PyTorch uses its default multithreading. Extra cores speed up each fit but
  don't parallelise across seeds.
- To use a different GPU, change gpu_id.

SEEDS
-----

- Number: not set in the runner, so the module default num_seeds=20 applies. To change it,
  add num_seeds=16 (for example) to the call on lines 76–97. The maximum is 20.
- Seed values: split seeds are the first num_seeds entries of the fixed list in FedMGP.py
  lines 180–185: 1, 7, 11, 19, 23, 31, 37, 41, 55, 70, 99, 105, 121, 135, 160, 202, 82, 114, 303,
  154 (the same list LT-NP uses). Training seed for seed k = train_seed + 1000·k (train_seed=220,
  line 93).
- split_seed is ignored by this module.
- What a seed controls: the 20% test set, the initial context (140), the pool, initialisation and
  ACS-FW sampling. BALD and ACS-FW start from the same split and the same initial fitted model.
- Influence: each seed is an independent replicate. The plot shows mean ± 1 standard error, which
  shrinks as seeds increase. Runtime is linear in num_seeds.

OTHER SETTINGS (LINES 76–97)
----------------------------

- acq_rounds
    Value: 20
    Meaning: acquisition rounds

- batch_size
    Value: 5
    Meaning: points per round

- num_latents
    Value: 1
    Meaning: shared latent GPs

- num_inducing
    Value: 30
    Meaning: pseudo-inputs

- acs_j
    Value: 50
    Meaning: posterior samples for ACS-FW

- initial_context_size
    Value: 140
    Meaning: initial labelled points

- train_seed
    Value: 220
    Meaning: base training seed

- response_start_index
    Value: 7
    Meaning: first response column (column 7 included)

- expected_num_outputs
    Value: 145
    Meaning: required curve length

- (module defaults) train_epochs, lr
    Value: 1000, 0.05
    Meaning: max local steps per fit (early stopping), learning rate

The pool must be strictly larger than acq_rounds × batch_size after removing the 20% test set and
the 140 context points. Otherwise the run stops with an error.

This runner includes column 7 in the response (145 outputs). R1-MTGP, WPV-GP and LT-NP skip it
(144 outputs). Make sure that is intended before comparing models.

OUTPUTS (IN SAVE_DIR/<SCENARIO NAME>/)
--------------------------------------

acquisition_metrics_all_strategies.csv, mape_trajectories_all_strategies.png, and
true_vs_predicted_9_curves_ACS_FW.png and true_vs_predicted_9_curves_BALD.png (first seed, final
model).
